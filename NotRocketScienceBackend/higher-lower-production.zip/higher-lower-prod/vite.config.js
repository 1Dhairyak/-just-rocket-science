import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { resolve } from 'path'

export default defineConfig({
  plugins: [react()],

  resolve: {
    alias: {
      // FIX ARCH-04: path aliases — import from '@/components/...' anywhere
      '@': resolve(__dirname, './src'),
    },
  },

  build: {
    rollupOptions: {
      output: {
        // FIX ARCH-04: manual chunk splitting — vendor libs cached separately
        manualChunks: {
          react: ['react', 'react-dom'],
          router: ['react-router-dom'],
          motion: ['framer-motion'],
          axios: ['axios'],
        },
      },
    },
  },
})
