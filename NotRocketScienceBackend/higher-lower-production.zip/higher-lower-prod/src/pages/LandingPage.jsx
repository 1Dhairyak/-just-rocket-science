import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { usePageVariants, staggerContainer, staggerItem } from '../animations/variants'
import { useGameContext } from '../context/GameContext'
import ParticleField from '../components/ui/ParticleField'
import StarfieldBg from '../components/ui/StarfieldBg'
import Logo from '../components/ui/Logo'
import Navbar from '../components/ui/Navbar'

const features = [
  {
    icon: '🌐',
    iconColor: '#00FF87',
    iconRGB: '0,255,135',
    title: 'Global Search Data',
    desc: 'Compare real search volumes from across the internet. No guessing — pure data.',
  },
  {
    icon: '⚡',
    iconColor: '#FFD700',
    iconRGB: '255,215,0',
    title: 'Speed Duel',
    desc: 'Lightning-fast rounds keep you sharp. How long can your streak last?',
  },
  {
    icon: '🎯',
    iconColor: '#00C2FF',
    iconRGB: '0,194,255',
    title: 'Elimination Mode',
    desc: "One wrong guess and it's over. Think carefully before you click.",
  },
]

const categories = [
  'Gaming', 'Movies', 'Celebrities', 'Sports',
  'Technology', 'Brands', 'Food', 'Anime', 'Memes',
]

export default function LandingPage() {
  const pageVariants = usePageVariants()
  // FIX ARCH-01: Read from context instead of calling localStorage.getItem directly
  const { highScore } = useGameContext()

  return (
    <motion.div
      variants={pageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      className="relative min-h-screen bg-game-darker overflow-hidden"
    >
      <Navbar />
      <StarfieldBg variant="dark" />
      <ParticleField count={70} color="#00FF87" />

      {/* ── Hero ─────────────────────────────────────────────────────────────── */}
      <section
        className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 pt-20"
        aria-label="Hero section"
      >
        {/* Early Access badge */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.5 }}
          className="mb-8 flex items-center gap-2 px-5 py-2 rounded-full"
          style={{
            background: 'rgba(0,255,135,0.08)',
            border: '1px solid rgba(0,255,135,0.3)',
            boxShadow: '0 0 20px rgba(0,255,135,0.1)',
          }}
        >
          <span className="text-game-green text-sm" aria-hidden="true">🚀</span>
          <span className="text-game-green text-sm font-mono font-bold tracking-widest uppercase">
            Early Access
          </span>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <Logo size="lg" animate />
        </motion.div>

        {/* Taglines */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.6 }}
          className="mt-6 text-center"
        >
          <p
            className="text-xl md:text-2xl font-body font-semibold text-white"
            style={{ textShadow: '0 2px 20px rgba(0,0,0,0.8)' }}
          >
            What gets Googled more?{' '}
            <span
              style={{
                background: 'linear-gradient(90deg, #00FF87, #00C2FF)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
              }}
            >
              Fresh Global Data.
            </span>
          </p>
          <p className="mt-3 text-white/50 text-base font-body max-w-md mx-auto leading-relaxed">
            Duel with up-to-the-minute global search trends across{' '}
            <span className="text-white/70">{categories.length} categories</span>.
          </p>
        </motion.div>

        {/* High score — from context, not raw localStorage */}
        {highScore > 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.8 }}
            className="mt-6 flex items-center gap-3 px-6 py-3 rounded-2xl"
            role="status"
            aria-label={`Your best score: ${highScore}`}
            style={{
              background: 'rgba(255,215,0,0.08)',
              border: '1px solid rgba(255,215,0,0.2)',
            }}
          >
            <span aria-hidden="true" className="text-2xl">🏆</span>
            <div>
              <p className="text-white/50 text-xs font-mono tracking-widest uppercase">Your Best</p>
              <p
                className="font-display text-2xl text-game-gold"
                style={{ textShadow: '0 0 20px rgba(255,215,0,0.6)' }}
              >
                {highScore}
              </p>
            </div>
          </motion.div>
        )}

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9, duration: 0.6 }}
          className="mt-10 flex flex-col sm:flex-row gap-4 items-center"
        >
          <Link to="/game">
            <motion.button
              whileHover={{ scale: 1.06 }}
              whileTap={{ scale: 0.95 }}
              className="relative px-10 py-4 rounded-full font-body font-bold text-lg text-black tracking-wide overflow-hidden focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-game-green focus-visible:ring-offset-2 focus-visible:ring-offset-game-darker"
              style={{
                background: 'linear-gradient(135deg, #00FF87 0%, #00C2FF 100%)',
                boxShadow: '0 0 40px rgba(0,255,135,0.5), 0 4px 20px rgba(0,0,0,0.4)',
              }}
            >
              <span className="relative z-10 flex items-center gap-3">
                START EXPLORING
                <span aria-hidden="true" className="text-xl">›</span>
              </span>
            </motion.button>
          </Link>

          <Link to="/leaderboard">
            <motion.button
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-4 rounded-full font-body font-semibold text-base text-white/70 hover:text-white tracking-wide transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-game-gold focus-visible:ring-offset-2 focus-visible:ring-offset-game-darker"
              style={{
                background: 'rgba(255,255,255,0.05)',
                border: '1px solid rgba(255,255,255,0.12)',
                backdropFilter: 'blur(10px)',
              }}
            >
              🏆 Leaderboard
            </motion.button>
          </Link>
        </motion.div>

        {/* Scroll hint */}
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/30"
          aria-hidden="true"
        >
          <span className="text-xs font-mono tracking-widest uppercase">Scroll</span>
          <span className="text-xl">↓</span>
        </motion.div>
      </section>

      {/* ── Scrolling category strip ─────────────────────────────────────────── */}
      <section className="relative z-10 py-16 overflow-hidden" aria-label="Game categories">
        <div
          className="absolute inset-y-0 left-0 w-16 z-10"
          style={{ background: 'linear-gradient(to right, #050A0F, transparent)' }}
          aria-hidden="true"
        />
        <div
          className="absolute inset-y-0 right-0 w-16 z-10"
          style={{ background: 'linear-gradient(to left, #050A0F, transparent)' }}
          aria-hidden="true"
        />
        <motion.div
          animate={{ x: [0, -1200] }}
          transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
          className="flex gap-4 w-max"
          aria-hidden="true"
        >
          {[...categories, ...categories, ...categories].map((cat, i) => (
            <span
              key={i}
              className="px-5 py-2 rounded-full text-sm font-mono font-bold tracking-widest uppercase whitespace-nowrap"
              style={{
                background: 'rgba(255,255,255,0.04)',
                border: '1px solid rgba(255,255,255,0.08)',
                color: i % 3 === 0 ? '#00FF87' : i % 3 === 1 ? '#00C2FF' : '#FFD700',
              }}
            >
              {cat}
            </span>
          ))}
        </motion.div>
      </section>

      {/* ── Features ─────────────────────────────────────────────────────────── */}
      <section
        className="relative z-10 py-20 px-4 max-w-6xl mx-auto"
        aria-label="Game features"
      >
        <motion.div
          variants={staggerContainer}
          initial="initial"
          whileInView="animate"
          viewport={{ once: true, margin: '-100px' }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          {features.map((f, i) => (
            <motion.div
              key={i}
              variants={staggerItem}
              whileHover={{ y: -8, scale: 1.02 }}
              transition={{ duration: 0.3 }}
              className="relative p-8 rounded-3xl overflow-hidden cursor-default"
              style={{
                background: 'rgba(255,255,255,0.03)',
                border: '1px solid rgba(255,255,255,0.08)',
                backdropFilter: 'blur(20px)',
              }}
            >
              <div
                className="absolute top-0 right-0 w-32 h-32 rounded-full blur-3xl opacity-20 pointer-events-none"
                aria-hidden="true"
                style={{ background: f.iconColor }}
              />
              <div className="relative z-10">
                <div
                  className="text-5xl mb-6 w-16 h-16 flex items-center justify-center rounded-2xl"
                  aria-hidden="true"
                  style={{
                    background: `rgba(${f.iconRGB},0.1)`,
                    border: `1px solid ${f.iconColor}30`,
                  }}
                >
                  {f.icon}
                </div>
                <h3
                  className="font-display text-2xl mb-3 tracking-wide"
                  style={{ color: f.iconColor }}
                >
                  {f.title}
                </h3>
                <p className="text-white/55 font-body text-sm leading-relaxed">{f.desc}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* ── Bottom CTA ───────────────────────────────────────────────────────── */}
      <section className="relative z-10 py-24 px-4 text-center" aria-label="Call to action">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <p className="font-display text-5xl md:text-7xl text-white mb-8 leading-none">
            READY TO{' '}
            <span className="text-game-green text-glow-green">TEST</span>
            <br />YOUR KNOWLEDGE?
          </p>
          <Link to="/game">
            <motion.button
              whileHover={{ scale: 1.06 }}
              whileTap={{ scale: 0.95 }}
              className="px-14 py-5 rounded-full font-body font-bold text-xl text-black tracking-wide focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-game-green focus-visible:ring-offset-2 focus-visible:ring-offset-game-darker"
              style={{
                background: 'linear-gradient(135deg, #00FF87 0%, #00C2FF 100%)',
                boxShadow: '0 0 60px rgba(0,255,135,0.4)',
              }}
            >
              PLAY FOR FREE
            </motion.button>
          </Link>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-white/5 py-8 px-4 text-center">
        <p className="text-white/25 text-xs font-mono tracking-widest">
          HIGHER OR LOWER GAME · PORTFOLIO PROJECT · BUILT WITH REACT + SPRING BOOT
        </p>
      </footer>
    </motion.div>
  )
}
