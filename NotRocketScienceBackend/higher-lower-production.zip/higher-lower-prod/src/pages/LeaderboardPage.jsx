import { useState, useMemo } from 'react'
import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import {
  usePageVariants,
  staggerContainer,
  staggerItem,
} from '../animations/variants'
import { useGameContext } from '../context/GameContext'
import { MOCK_LEADERBOARD } from '../services/mockData'
import { getRankColor, getRankRGB } from '../services/formatters'
import StarfieldBg from '../components/ui/StarfieldBg'
import ParticleField from '../components/ui/ParticleField'
import Navbar from '../components/ui/Navbar'

const RANK_MEDALS = { 1: '🥇', 2: '🥈', 3: '🥉' }
const CATEGORIES = ['All', 'Gaming', 'Movies', 'Celebrities', 'Technology', 'Food']

function RankBadge({ rank }) {
  const color = getRankColor(rank)
  const medal = RANK_MEDALS[rank]
  const rgb = getRankRGB(rank)

  return (
    <div
      className="w-10 h-10 rounded-full flex items-center justify-center font-display text-lg shrink-0"
      aria-label={medal ? `Rank ${rank} — ${medal}` : `Rank ${rank}`}
      style={{
        background:
          rank <= 3
            ? `radial-gradient(circle, rgba(${rgb},0.2), transparent)`
            : 'rgba(255,255,255,0.04)',
        border: `1px solid rgba(${rgb},0.3)`,
        color,
        textShadow: rank <= 3 ? `0 0 10px ${color}` : 'none',
      }}
    >
      {medal || rank}
    </div>
  )
}

export default function LeaderboardPage() {
  const [filter, setFilter] = useState('All')
  const pageVariants = usePageVariants()
  const { highScore } = useGameContext()

  // FIX PERF-04: memoized filter — won't recompute on every render.
  // Phase 4: replace MOCK_LEADERBOARD with leaderboardService.getTop(10, filter)
  const filtered = useMemo(
    () =>
      filter === 'All'
        ? MOCK_LEADERBOARD
        : MOCK_LEADERBOARD.filter((e) => e.category === filter),
    [filter]
  )

  return (
    <motion.div
      variants={pageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      className="relative min-h-screen bg-game-darker overflow-hidden"
    >
      <StarfieldBg variant="green" />
      <ParticleField count={40} color="#FFD700" />
      <Navbar />

      <div className="relative z-10 max-w-3xl mx-auto px-4 pt-28 pb-20">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-10"
        >
          <div aria-hidden="true" className="text-5xl mb-4">🏆</div>
          <h1
            className="font-display text-5xl sm:text-6xl md:text-8xl text-white tracking-wider"
            style={{ textShadow: '0 0 40px rgba(255,215,0,0.4)' }}
          >
            LEADERBOARD
          </h1>
          <p className="mt-3 text-white/40 font-mono text-sm tracking-widest uppercase">
            Top scores from around the world
          </p>
        </motion.div>

        {/* Your best score */}
        {highScore > 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            className="mb-8 flex items-center justify-between px-6 py-4 rounded-2xl"
            role="status"
            aria-label={`Your best score: ${highScore}`}
            style={{
              background: 'rgba(0,255,135,0.06)',
              border: '1px solid rgba(0,255,135,0.2)',
              boxShadow: '0 0 20px rgba(0,255,135,0.05)',
            }}
          >
            <div className="flex items-center gap-3">
              <span aria-hidden="true" className="text-2xl">⚡</span>
              <div>
                <p className="text-white/40 text-xs font-mono tracking-widest uppercase">Your Best</p>
                <p className="text-white font-body font-semibold">You</p>
              </div>
            </div>
            <span
              className="font-display text-3xl sm:text-4xl text-game-green"
              style={{ textShadow: '0 0 20px rgba(0,255,135,0.6)' }}
            >
              {highScore}
            </span>
          </motion.div>
        )}

        {/* Category filter */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="flex flex-wrap gap-2 mb-8 justify-center"
          role="group"
          aria-label="Filter by category"
        >
          {CATEGORIES.map((cat) => {
            const isActive = filter === cat
            return (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                aria-pressed={isActive}
                className="px-4 py-2 rounded-full text-xs font-mono font-bold tracking-widest uppercase transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-game-gold focus-visible:ring-offset-1 focus-visible:ring-offset-game-darker"
                style={{
                  background: isActive ? 'rgba(255,215,0,0.15)' : 'rgba(255,255,255,0.04)',
                  border: `1px solid ${isActive ? 'rgba(255,215,0,0.5)' : 'rgba(255,255,255,0.08)'}`,
                  color: isActive ? '#FFD700' : 'rgba(255,255,255,0.5)',
                  boxShadow: isActive ? '0 0 15px rgba(255,215,0,0.15)' : 'none',
                }}
              >
                {cat}
              </button>
            )
          })}
        </motion.div>

        {/* FIX A11Y-06: Semantic <table> instead of div rows */}
        <motion.div variants={staggerContainer} initial="initial" animate="animate">
          <table
            className="w-full border-collapse"
            aria-label="Leaderboard rankings"
          >
            <thead>
              <tr>
                <th scope="col" className="pb-3 text-left">
                  <span className="text-white/25 text-xs font-mono tracking-widest uppercase pl-6">#</span>
                </th>
                <th scope="col" className="pb-3 text-left">
                  <span className="text-white/25 text-xs font-mono tracking-widest uppercase">Player</span>
                </th>
                <th scope="col" className="pb-3 text-right hidden sm:table-cell">
                  <span className="text-white/25 text-xs font-mono tracking-widest uppercase pr-4">Category</span>
                </th>
                <th scope="col" className="pb-3 text-right">
                  <span className="text-white/25 text-xs font-mono tracking-widest uppercase pr-2">Score</span>
                </th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((entry) => {
                const rankColor = getRankColor(entry.rank)
                const rankRGB = getRankRGB(entry.rank)
                const isTop3 = entry.rank <= 3

                return (
                  <motion.tr
                    key={entry.rank}
                    variants={staggerItem}
                    whileHover={{ x: 4, scale: 1.01 }}
                    transition={{ duration: 0.2 }}
                    className="relative overflow-hidden"
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '1rem',
                      padding: '1rem 1.5rem',
                      borderRadius: '1rem',
                      marginBottom: '0.5rem',
                      background: isTop3
                        ? `rgba(${rankRGB},0.06)`
                        : 'rgba(255,255,255,0.03)',
                      border: `1px solid ${
                        isTop3 ? `rgba(${rankRGB},0.15)` : 'rgba(255,255,255,0.06)'
                      }`,
                      boxShadow: isTop3 ? `0 0 20px rgba(${rankRGB},0.06)` : 'none',
                    }}
                  >
                    {isTop3 && (
                      <td
                        aria-hidden="true"
                        style={{
                          position: 'absolute',
                          inset: '0 auto 0 0',
                          width: '3px',
                          borderRadius: '0 2px 2px 0',
                          background: rankColor,
                          boxShadow: `0 0 10px ${rankColor}`,
                        }}
                      />
                    )}

                    <td style={{ flexShrink: 0, paddingLeft: '0.5rem' }}>
                      <RankBadge rank={entry.rank} />
                    </td>

                    <td style={{ flex: 1, minWidth: 0 }}>
                      <span
                        className="font-body font-semibold text-sm sm:text-base block truncate"
                        style={{ color: isTop3 ? rankColor : 'white' }}
                      >
                        {entry.playerName}
                      </span>
                      <span className="text-white/30 text-xs font-mono">{entry.date}</span>
                    </td>

                    <td
                      className="hidden sm:table-cell"
                      style={{ width: '6rem', textAlign: 'right' }}
                    >
                      <span className="text-xs font-mono text-white/35 truncate">
                        {entry.category}
                      </span>
                    </td>

                    <td style={{ width: '4rem', textAlign: 'right', flexShrink: 0 }}>
                      <span
                        className="font-display text-2xl sm:text-3xl"
                        style={{
                          color: isTop3 ? rankColor : 'white',
                          textShadow: isTop3
                            ? `0 0 15px rgba(${rankRGB},0.5)`
                            : 'none',
                        }}
                      >
                        {entry.score}
                      </span>
                    </td>
                  </motion.tr>
                )
              })}
            </tbody>
          </table>
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="mt-12 text-center"
        >
          <p className="text-white/30 text-sm font-body mb-6">
            Think you can crack the top 10?
          </p>
          <Link to="/game">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-10 py-4 rounded-full font-body font-bold text-black text-lg tracking-wide focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-game-gold focus-visible:ring-offset-2 focus-visible:ring-offset-game-darker"
              style={{
                background: 'linear-gradient(135deg, #FFD700, #FF8C00)',
                boxShadow: '0 0 30px rgba(255,215,0,0.3)',
              }}
            >
              🎮 BEAT THE LEADERBOARD
            </motion.button>
          </Link>
        </motion.div>
      </div>
    </motion.div>
  )
}
