import { useState, useCallback, useRef, useEffect } from 'react'
import { MOCK_ITEMS } from '../services/mockData'
import { useGameContext } from '../context/GameContext'

function shuffle(arr) {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

// FIX ARCH-03: async-ready fetch function. Phase 4: swap body for API call.
// Hook's external interface stays identical — pages don't need to change.
async function fetchItems() {
  // TODO Phase 4: return await gameService.startSession()
  return shuffle(MOCK_ITEMS)
}

export function useGame() {
  const { updateHighScore } = useGameContext()

  const [deck, setDeck] = useState(() => shuffle(MOCK_ITEMS))
  const [leftIndex, setLeftIndex] = useState(0)
  const [rightIndex, setRightIndex] = useState(1)
  const [score, setScore] = useState(0)
  const [phase, setPhase] = useState('playing') // 'playing' | 'correct' | 'wrong'
  const [lastGuess, setLastGuess] = useState(null)

  // FIX ARCH-03: loading + error states — async-ready for Phase 4
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState(null)

  // FIX BUG-05: Use ref to store the timeout ID so we can always clear it,
  // eliminating the stale-closure race condition from raw setTimeout.
  const advanceTimerRef = useRef(null)

  // Prevent setState-on-unmounted-component warnings
  useEffect(() => {
    return () => {
      if (advanceTimerRef.current) clearTimeout(advanceTimerRef.current)
    }
  }, [])

  const leftItem = deck[leftIndex] ?? null
  const rightItem = deck[rightIndex] ?? null

  const guess = useCallback(
    (direction) => {
      if (phase !== 'playing' || !leftItem || !rightItem) return

      const isHigher = rightItem.searchVolume >= leftItem.searchVolume
      const correct = direction === 'higher' ? isHigher : !isHigher

      setLastGuess(direction)

      if (correct) {
        setPhase('correct')

        advanceTimerRef.current = setTimeout(() => {
          // FIX BUG-05: Use functional setState forms so callbacks capture
          // the latest value, not a stale closure snapshot.
          setScore((prev) => {
            const next = prev + 1
            updateHighScore(next)
            return next
          })

          setDeck((prevDeck) => {
            const nextRight = rightIndex + 1
            if (nextRight >= prevDeck.length) {
              const newDeck = shuffle(MOCK_ITEMS)
              setLeftIndex(0)
              setRightIndex(1)
              return newDeck
            }
            setLeftIndex(rightIndex)
            setRightIndex(nextRight)
            return prevDeck
          })

          setPhase('playing')
        }, 1200)
      } else {
        setPhase('wrong')
      }
    },
    [phase, leftItem, rightItem, rightIndex, updateHighScore]
  )

  const reset = useCallback(async () => {
    if (advanceTimerRef.current) clearTimeout(advanceTimerRef.current)
    setIsLoading(true)
    setError(null)
    try {
      const items = await fetchItems()
      setDeck(items)
      setLeftIndex(0)
      setRightIndex(1)
      setScore(0)
      setPhase('playing')
      setLastGuess(null)
    } catch (e) {
      setError(e.message || 'Failed to load game data')
    } finally {
      setIsLoading(false)
    }
  }, [])

  return {
    leftItem,
    rightItem,
    score,
    phase,
    lastGuess,
    isLoading,
    error,
    guess,
    reset,
  }
}
