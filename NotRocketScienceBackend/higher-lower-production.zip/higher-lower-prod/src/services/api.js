/**
 * API Service Layer — Phase 4 ready
 *
 * FIX ARCH-02: All backend calls go through here. useGame and pages
 * never import axios directly. Single place to:
 *  - Swap base URL per environment (VITE_API_BASE_URL)
 *  - Add auth headers (Phase 5 JWT)
 *  - Normalize error shapes across the whole app
 *  - Add retry logic
 */

import axios from 'axios'

const BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api'

export const apiClient = axios.create({
  baseURL: BASE_URL,
  timeout: 10_000,
  headers: { 'Content-Type': 'application/json' },
})

// ── Request interceptor ───────────────────────────────────────────────────────
apiClient.interceptors.request.use((config) => {
  // Phase 5: inject JWT
  // const token = localStorage.getItem('hl_token')
  // if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// ── Response interceptor ──────────────────────────────────────────────────────
apiClient.interceptors.response.use(
  (res) => res.data,
  (err) => {
    const message =
      err.response?.data?.message ||
      err.response?.data?.error ||
      err.message ||
      'An unexpected error occurred'
    return Promise.reject(new Error(message))
  }
)

// ── Game Service ──────────────────────────────────────────────────────────────

export const gameService = {
  /** Start a new game session → { sessionId, firstPair: { left, right } } */
  startSession: () => apiClient.post('/sessions'),

  /** Submit a guess → { correct: boolean, nextItem: Item, score: number } */
  submitGuess: (sessionId, direction) =>
    apiClient.post(`/sessions/${sessionId}/guess`, { direction }),

  /** End session and persist final score */
  endSession: (sessionId, score) =>
    apiClient.post(`/sessions/${sessionId}/end`, { score }),
}

// ── Leaderboard Service ───────────────────────────────────────────────────────

export const leaderboardService = {
  /** Fetch top N entries → { entries: LeaderboardEntry[] } */
  getTop: (limit = 10, category = 'All') =>
    apiClient.get('/leaderboard', { params: { limit, category } }),

  /** Submit a score → { rank: number } */
  submitScore: (playerName, score, category) =>
    apiClient.post('/leaderboard', { playerName, score, category }),
}
