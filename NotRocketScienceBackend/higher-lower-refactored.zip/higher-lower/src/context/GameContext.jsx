import { createContext, useContext, useState, useCallback } from 'react'

const GameContext = createContext(null)

export function GameProvider({ children }) {
  const [highScore, setHighScoreState] = useState(() =>
    Number(localStorage.getItem('hl_highscore') || 0)
  )
  // Track prev best so GameOverPage can correctly detect a new high score
  const [prevBest] = useState(() =>
    Number(localStorage.getItem('hl_highscore') || 0)
  )

  const updateHighScore = useCallback((score) => {
    if (score > highScore) {
      // Save old best before overwriting so GameOverPage can compare
      localStorage.setItem('hl_prev_best', String(highScore))
      localStorage.setItem('hl_highscore', String(score))
      setHighScoreState(score)
    }
  }, [highScore])

  return (
    <GameContext.Provider value={{ highScore, prevBest, updateHighScore }}>
      {children}
    </GameContext.Provider>
  )
}

export function useGameContext() {
  const ctx = useContext(GameContext)
  if (!ctx) throw new Error('useGameContext must be used within GameProvider')
  return ctx
}
