import { motion } from 'framer-motion'
import { staggerContainer, staggerItem } from '../../animations/variants'

const SIZES = {
  sm: { higher: 'text-4xl', lower: 'text-4xl' },
  md: { higher: 'text-6xl', lower: 'text-6xl' },
  lg: { higher: 'text-8xl md:text-9xl', lower: 'text-8xl md:text-9xl' },
  xl: { higher: 'text-9xl', lower: 'text-9xl' },
}

export default function Logo({ size = 'lg', animate = true }) {
  const s = SIZES[size] ?? SIZES.lg

  // FIX: Always use motion.div — conditionally applying a non-motion wrapper
  // was causing React to treat it as a new component type each render,
  // forcing a full unmount/remount and breaking layout animations.
  return (
    <motion.div
      className="flex flex-col items-center leading-none select-none"
      variants={animate ? staggerContainer : undefined}
      initial={animate ? 'initial' : undefined}
      animate={animate ? 'animate' : undefined}
    >
      <motion.span
        variants={animate ? staggerItem : undefined}
        className={`font-display ${s.higher} text-game-green tracking-wider`}
        style={{
          textShadow: '0 0 30px rgba(0,255,135,0.8), 0 0 60px rgba(0,255,135,0.4)',
          WebkitTextStroke: '1px rgba(0,255,135,0.3)',
        }}
      >
        ↑HIGHER
      </motion.span>
      <motion.span
        variants={animate ? staggerItem : undefined}
        className={`font-display ${s.lower} text-game-red tracking-wider`}
        style={{
          textShadow: '0 0 30px rgba(255,60,60,0.8), 0 0 60px rgba(255,60,60,0.4)',
          WebkitTextStroke: '1px rgba(255,60,60,0.3)',
        }}
      >
        LOWER↓
      </motion.span>
    </motion.div>
  )
}
