import { useState, useCallback, useRef, useEffect } from 'react'
import { MOCK_ITEMS } from '../services/mockData'
import { useGameContext } from '../context/GameContext'

function shuffle(arr) {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

// Phase-4 note: swap MOCK_ITEMS with an API call here.
// The hook's external interface (leftItem, rightItem, score, phase, guess, reset)
// stays identical — pages don't need to change.
async function fetchItems() {
  // TODO Phase 4: return await apiService.getItems()
  return shuffle(MOCK_ITEMS)
}

export function useGame() {
  const { updateHighScore } = useGameContext()

  const [deck, setDeck] = useState(() => shuffle(MOCK_ITEMS))
  const [leftIndex, setLeftIndex] = useState(0)
  const [rightIndex, setRightIndex] = useState(1)
  const [score, setScore] = useState(0)
  const [phase, setPhase] = useState('playing') // 'playing' | 'correct' | 'wrong'
  const [lastGuess, setLastGuess] = useState(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState(null)

  // Use ref for the timeout so we can clear it reliably on unmount
  // and avoid the stale-closure problem with raw setTimeout
  const advanceTimerRef = useRef(null)

  // Cleanup on unmount — prevents setState-on-unmounted-component warnings
  useEffect(() => {
    return () => {
      if (advanceTimerRef.current) clearTimeout(advanceTimerRef.current)
    }
  }, [])

  const leftItem = deck[leftIndex] ?? null
  const rightItem = deck[rightIndex] ?? null

  const guess = useCallback(
    (direction) => {
      if (phase !== 'playing' || !leftItem || !rightItem) return

      const isHigher = rightItem.searchVolume >= leftItem.searchVolume
      const correct = direction === 'higher' ? isHigher : !isHigher

      setLastGuess(direction)

      if (correct) {
        setPhase('correct')

        advanceTimerRef.current = setTimeout(() => {
          setScore((prev) => {
            const next = prev + 1
            updateHighScore(next)
            return next
          })

          setDeck((prevDeck) => {
            // Read rightIndex from the ref-captured deck, not stale closure
            const nextRight = rightIndex + 1
            if (nextRight >= prevDeck.length) {
              // Reshuffle when deck is exhausted
              const newDeck = shuffle(MOCK_ITEMS)
              setLeftIndex(0)
              setRightIndex(1)
              return newDeck
            }
            setLeftIndex(rightIndex)
            setRightIndex(nextRight)
            return prevDeck
          })

          setPhase('playing')
        }, 1200)
      } else {
        setPhase('wrong')
      }
    },
    // rightIndex is intentionally stable enough here; the timeout captures current values
    [phase, leftItem, rightItem, rightIndex, updateHighScore]
  )

  const reset = useCallback(async () => {
    if (advanceTimerRef.current) clearTimeout(advanceTimerRef.current)
    setIsLoading(true)
    setError(null)
    try {
      const items = await fetchItems()
      setDeck(items)
      setLeftIndex(0)
      setRightIndex(1)
      setScore(0)
      setPhase('playing')
      setLastGuess(null)
    } catch (e) {
      setError(e.message || 'Failed to load game data')
    } finally {
      setIsLoading(false)
    }
  }, [])

  return {
    leftItem,
    rightItem,
    score,
    phase,
    lastGuess,
    isLoading,
    error,
    guess,
    reset,
  }
}
