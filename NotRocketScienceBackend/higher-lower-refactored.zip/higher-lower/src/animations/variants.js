import { useReducedMotion } from 'framer-motion'

// ─── Page Transitions ─────────────────────────────────────────────────────────
export const pageVariants = {
  initial: { opacity: 0, y: 20, filter: 'blur(8px)' },
  animate: {
    opacity: 1,
    y: 0,
    filter: 'blur(0px)',
    transition: { duration: 0.5, ease: [0.25, 0.46, 0.45, 0.94] },
  },
  exit: {
    opacity: 0,
    y: -20,
    filter: 'blur(8px)',
    transition: { duration: 0.3, ease: [0.55, 0, 1, 0.45] },
  },
}

// Minimal version for reduced motion preference
export const pageVariantsReduced = {
  initial: { opacity: 0 },
  animate: { opacity: 1, transition: { duration: 0.2 } },
  exit: { opacity: 0, transition: { duration: 0.15 } },
}

// ─── Stagger Container ────────────────────────────────────────────────────────
// FIX: Added `initial` key — without it, children have no baseline to animate from
export const staggerContainer = {
  initial: {},
  animate: {
    transition: { staggerChildren: 0.08, delayChildren: 0.1 },
  },
}

export const staggerItem = {
  initial: { opacity: 0, y: 40 },
  animate: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: [0.25, 0.46, 0.45, 0.94] },
  },
}

// ─── Card Animations ──────────────────────────────────────────────────────────
export const slideInRight = {
  initial: { x: '100%', opacity: 0 },
  animate: {
    x: 0,
    opacity: 1,
    transition: { duration: 0.5, ease: [0.25, 0.46, 0.45, 0.94] },
  },
  exit: {
    x: '-100%',
    opacity: 0,
    transition: { duration: 0.4, ease: [0.55, 0, 1, 0.45] },
  },
}

// ─── Shake (wrong answer) ─────────────────────────────────────────────────────
export const shakeVariant = {
  shake: {
    x: [-8, 8, -8, 8, -4, 4, 0],
    transition: { duration: 0.5, ease: 'easeInOut' },
  },
}

// ─── Fade + Scale ─────────────────────────────────────────────────────────────
export const fadeScale = {
  initial: { opacity: 0, scale: 0.8 },
  animate: {
    opacity: 1,
    scale: 1,
    transition: { duration: 0.5, ease: [0.25, 0.46, 0.45, 0.94] },
  },
  exit: {
    opacity: 0,
    scale: 0.8,
    transition: { duration: 0.3 },
  },
}

// ─── Score Reveal (Game Over) ─────────────────────────────────────────────────
export const scoreReveal = {
  initial: { scale: 0, rotate: -10 },
  animate: {
    scale: 1,
    rotate: 0,
    transition: { type: 'spring', stiffness: 200, damping: 15, delay: 0.4 },
  },
}

// ─── Reveal Up ────────────────────────────────────────────────────────────────
export const revealUp = {
  initial: { opacity: 0, y: 60 },
  animate: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: [0.25, 0.46, 0.45, 0.94] },
  },
}

// ─── usePageVariants — picks reduced motion variant automatically ──────────────
// Usage: const variants = usePageVariants()
// Then:  <motion.div variants={variants} initial="initial" animate="animate" exit="exit">
export function usePageVariants() {
  const shouldReduce = useReducedMotion()
  return shouldReduce ? pageVariantsReduced : pageVariants
}
