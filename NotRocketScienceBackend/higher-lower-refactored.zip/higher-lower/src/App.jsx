import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom'
import { AnimatePresence } from 'framer-motion'
import { GameProvider } from './context/GameContext'
import LandingPage from './pages/LandingPage'
import GamePage from './pages/GamePage'
import GameOverPage from './pages/GameOverPage'
import LeaderboardPage from './pages/LeaderboardPage'
import NotFoundPage from './pages/NotFoundPage'

// AnimatePresence MUST receive a changing key to fire exit animations.
// Wrapping Routes in a component that consumes useLocation is the canonical fix.
function AnimatedRoutes() {
  const location = useLocation()

  return (
    <AnimatePresence mode="wait" initial={false}>
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<LandingPage />} />
        <Route path="/game" element={<GamePage />} />
        <Route path="/game-over" element={<GameOverPage />} />
        <Route path="/leaderboard" element={<LeaderboardPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </AnimatePresence>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      {/* GameProvider gives all pages access to highScore without prop drilling or repeated localStorage reads */}
      <GameProvider>
        <AnimatedRoutes />
      </GameProvider>
    </BrowserRouter>
  )
}
