import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { resolve } from 'path'

export default defineConfig({
  plugins: [react()],

  resolve: {
    alias: {
      // Allows: import X from '@/components/...' instead of '../../components/...'
      '@': resolve(__dirname, './src'),
    },
  },

  build: {
    rollupOptions: {
      output: {
        // Split vendor libraries into a separate chunk so they can be cached
        // separately from application code (helps with cache invalidation).
        manualChunks: {
          react: ['react', 'react-dom'],
          router: ['react-router-dom'],
          motion: ['framer-motion'],
          axios: ['axios'],
        },
      },
    },
  },
})
